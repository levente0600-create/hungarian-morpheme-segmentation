"""
Modified rule-based Hungarian morpheme segmentation prototype.

This version includes a small lexical exception list introduced after
evaluation on unseen data. The modification was added to reduce
over-segmentation errors on common Hungarian words that should not
be morphologically segmented.
"""

from rules import PREFIXES, ALL_SUFFIXES
from exceptions import EXCEPTIONS


def segment_word(word):
    """
    Segment one Hungarian word using simple prefix and suffix matching.
    """

    original_word = word
    segments = []
    word = word.strip()

    # ------------------------------------------------------------------
    # Refinement introduced after evaluation phase:
    # Prevent segmentation of common lexical items that superficially
    # resemble segmentable forms (e.g. "nem" -> "ne + m").
    # ------------------------------------------------------------------
    if word.lower() in EXCEPTIONS:
        return original_word

    # ------------------------------------------------------------------
    # Step 1: Detect verbal prefixes
    # ------------------------------------------------------------------
    for prefix in PREFIXES:
        if word.lower().startswith(prefix.lower()) and len(word) > len(prefix) + 2:
            segments.append(word[:len(prefix)])
            word = word[len(prefix):]
            break

    # ------------------------------------------------------------------
    # Step 2: Detect suffixes (longest first)
    # ------------------------------------------------------------------
    for suffix in ALL_SUFFIXES:
        if word.lower().endswith(suffix.lower()) and len(word) > len(suffix) + 1:
            stem = word[:-len(suffix)]
            segments.append(stem)
            segments.append(word[-len(suffix):])
            return " + ".join(segments)

    # ------------------------------------------------------------------
    # Step 3: Return prefix + stem if no suffix was found
    # ------------------------------------------------------------------
    if segments:
        segments.append(word)
        return " + ".join(segments)

    return original_word


def segment_sentence(sentence):
    """
    Segment every word in a sentence.
    """

    words = sentence.strip().split()
    segmented_words = []

    for word in words:

        # Remove simple punctuation for processing
        clean_word = word.strip(".,!?;:\"()")

        punctuation = ""
        if word.endswith((".", ",", "!", "?", ";", ":")):
            punctuation = word[-1]

        if clean_word:
            segmented_words.append(
                segment_word(clean_word) + punctuation
            )

    return " ".join(segmented_words)


if __name__ == "__main__":

    test_words = [
        "nem",
        "igen",
        "házban",
        "halni",
        "vagyok",
        "megismerhettelek",
        "futottunk",
        "tudatában",
        "barátaimmal",
        "dumálni",
    ]

    print("\n--- Hungarian Morpheme Segmentation Prototype ---\n")

    for word in test_words:
        print(f"{word} -> {segment_word(word)}")
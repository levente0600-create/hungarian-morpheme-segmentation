"""
Rule inventories for the Hungarian morpheme segmentation prototype.

These lists are intentionally limited. The goal is not full Hungarian
morphological analysis, but a transparent prototype covering selected
productive patterns observed in the curated subtitle data.
"""

# Verbal prefixes
PREFIXES = [
    "össze",
    "meg",
    "el",
]

# Case suffixes
CASE_SUFFIXES = [
    "tól", "től",
    "ban", "ben",
    "nak", "nek",
    "ról", "ről",
    "ra", "re",
    "ig",
    "t",
]

# Verb/person endings
VERB_SUFFIXES = [
    "telek",
    "otok", "etek", "ötök",
    "unk", "ünk",
    "ok", "ek", "ök",
    "om", "em",
    "sz",
]

# Infinitive suffix
INFINITIVE_SUFFIXES = [
    "ni",
]

# Derivational suffixes
DERIVATIONAL_SUFFIXES = [
    "abb",
    "an", "en",
    "ó", "ő",
    "i",
]

# Possessive-related endings
POSSESSIVE_SUFFIXES = [
    "aimmal", "eimmel",
    "em", "om",
    "m",
]

# Ordered from longest to shortest to avoid incorrect early matching
ALL_SUFFIXES = sorted(
    CASE_SUFFIXES
    + VERB_SUFFIXES
    + INFINITIVE_SUFFIXES
    + DERIVATIONAL_SUFFIXES
    + POSSESSIVE_SUFFIXES,
    key=len,
    reverse=True
)
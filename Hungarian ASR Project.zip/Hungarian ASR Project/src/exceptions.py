"""
Lexical exceptions for the Hungarian morpheme segmentation prototype.

These are common words that should not be segmented even if they appear
to end in a known suffix.
"""

EXCEPTIONS = [
    "nem",
    "igen",
    "mert",
    "hogy",
    "és",
    "de",
    "ha",
    "is",
    "az",
    "ez",
    "én",
    "te",
    "ő",
]
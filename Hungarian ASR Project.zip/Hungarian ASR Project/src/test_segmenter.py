"""
Test script for the Hungarian morpheme segmentation prototype.

Reads test items from data/test_sentences.txt and exports system outputs
to results/test_outputs.csv for manual evaluation.
"""

import csv
import os
import re
from segmenter import segment_word


INPUT_PATH = "../data/test_sentences.txt"
OUTPUT_PATH = "../results/test_outputs.csv"


def extract_words_from_line(line):
    """
    Light tokenization: extracts word-like Hungarian tokens from a sentence.
    """
    return re.findall(r"[A-Za-zÁÉÍÓÖŐÚÜŰáéíóöőúüű]+", line)


def export_results():
    os.makedirs("../results", exist_ok=True)

    with open(INPUT_PATH, "r", encoding="utf-8") as infile:
        lines = infile.readlines()

    with open(OUTPUT_PATH, "w", encoding="utf-8", newline="") as csvfile:
        writer = csv.writer(csvfile)

        writer.writerow([
            "source_sentence",
            "input_word",
            "system_output",
            "manual_gold",
            "status",
            "comments"
        ])

        for line in lines:
            line = line.strip()
            if not line:
                continue

            words = extract_words_from_line(line)

            for word in words:
                writer.writerow([
                    line,
                    word,
                    segment_word(word),
                    "",
                    "",
                    ""
                ])

    print(f"Test outputs exported to: {OUTPUT_PATH}")


if __name__ == "__main__":
    export_results()
RULE-BASED MORPHEME SEGMENTATION FOR CONVERSATIONAL HUNGARIAN

PROJECT OVERVIEW

This project explores the challenges of Hungarian morphological segmentation through the development of a small rule-based morpheme segmentation prototype. The project was motivated by broader issues in Hungarian NLP and ASR research, particularly the difficulties posed by Hungarian’s highly agglutinative morphology and the lack of standardized approaches to segmentation and annotation.

Rather than attempting to build a large-scale neural system, the project focuses on a transparent and interpretable rule-based approach applied to a small conversational corpus derived from Hungarian subtitle dialogue. The aim was to investigate which Hungarian morphological patterns can be handled successfully using relatively simple deterministic rules, while also identifying the limitations of this approach.

The prototype was implemented in Python and tested on unseen subtitle-derived conversational data.

PROBLEM STATEMENT

Hungarian presents several challenges for NLP systems due to its rich morphology and productive suffixation. A single lexical root may appear in many surface forms through combinations of case suffixes, possessive morphology, tense markers, derivational morphology, and verbal prefixes. This creates sparsity problems for word-level NLP systems because many surface forms occur infrequently despite sharing common stems.

Previous research also highlights several broader difficulties in Hungarian ASR and NLP research, including:

- inconsistent transcription conventions
- limited conversational speech data
- overrepresentation of read speech
- varying segmentation standards
- limited methodological transparency across corpora

Morphological segmentation has therefore been proposed as a useful strategy for reducing sparsity and improving linguistic generalization in morphologically rich languages such as Hungarian.

This project investigates whether a small rule-based system can successfully segment selected productive Hungarian morphemes in conversational text.

DATASET

The dataset used in this project consists of manually selected Hungarian subtitle dialogue derived from a conversational film corpus. Subtitle dialogue was chosen because it approximates spontaneous spoken interaction more closely than formal written text while remaining relatively easy to access and process in a small-scale project.

The project used:
- a small manually curated subtitle-derived corpus
- a manually segmented gold-standard subset
- a separate unseen evaluation set

The dataset was intentionally kept small in order to prioritize transparency, manual inspection, and qualitative evaluation over large-scale statistical experimentation.

METHODOLOGY

The project uses a rule-based segmentation approach implemented in Python.

The prototype operates using:
- verbal prefix inventories
- suffix inventories
- deterministic suffix matching
- lexical exception handling

The implementation focused only on a limited set of productive and transparent Hungarian morphological phenomena, including:

VERBAL PREFIXES
- meg-
- el-
- össze-

CASE SUFFIXES
- -ban/-ben
- -nak/-nek
- -tól/-től
- -ig
- -t

VERB MORPHOLOGY
- infinitive suffix -ni
- selected person/number agreement suffixes

DERIVATIONAL MORPHOLOGY
- -an/-en
- -i
- -abb
- selected adjectival and derivational suffixes

The prototype prioritizes interpretability and explicit linguistic rules rather than machine learning or probabilistic inference.

PROTOTYPE STRUCTURE

The project is organized into several components.

"rules.py"
Stores inventories of prefixes and suffixes used by the segmentation system.

"exceptions.py"
Contains lexical items that should not be segmented despite superficially resembling morphologically complex forms.

"segmenter.py"
Implements the main segmentation logic using deterministic rule matching.

"test_segmenter.py"
Applies the segmentation system to unseen subtitle-derived data and exports outputs for evaluation.

"gold_segmentations.txt"
Contains manually segmented reference examples used during development.

EVALUATION

The prototype was evaluated qualitatively on unseen subtitle-derived conversational data.

Outputs were exported into CSV format and manually inspected. Evaluation focused primarily on:
- successful segmentation patterns
- partial segmentation failures
- over-segmentation
- stacked morphology difficulties

Rather than calculating large-scale quantitative metrics, the project emphasized qualitative error analysis in line with the exploratory scope of the prototype.

Representative successful segmentations included:
- `hal + ni`
- `vagy + ok`
- `randi + ra`

Representative failures included:
- incomplete parsing of possessive linking vowels
- incorrect handling of past tense morphology
- over-segmentation of lexical roots
- incomplete segmentation of stacked derivational morphology

FINDINGS

The evaluation demonstrated that rule-based segmentation performs reasonably well on transparent and productive Hungarian morphology, particularly:
- infinitive suffixes
- common case endings
- simple verbal agreement markers

However, the prototype struggled with:
- stacked morphology
- possessive linking vowels
- derivational chains
- tense-related morphology
- lexical ambiguity

One particularly important finding involved over-segmentation. Some lexical items were incorrectly segmented because they superficially resembled morphologically complex forms. This demonstrated the importance of lexical constraints in rule-based systems.

The refinement stage therefore introduced a small lexical exception component intended to reduce incorrect segmentation of common non-segmentable forms.

LIMITATIONS

This project has several important limitations.

- The dataset is very small and manually curated.
- The prototype does not perform recursive segmentation.
- Phonological normalization and vowel harmony are not modeled.
- The rule inventory remains limited.
- Evaluation was qualitative rather than quantitative.
- The system cannot resolve morphological ambiguity.
- Conversational subtitle dialogue only approximates spoken Hungarian rather than representing genuine spontaneous speech.

The prototype should therefore be understood as an exploratory proof-of-concept rather than a complete Hungarian morphological analyzer.

FUTURE WORK

Possible future improvements include:
- expanding the rule inventory
- improving handling of tense-related morphology
- recursive segmentation of stacked morphemes
- larger conversational corpora
- improved lexical exception handling
- integration with multilingual ASR preprocessing pipelines
- comparison with statistical or neural segmentation approaches

Future versions could also incorporate genuine spoken Hungarian corpora in order to evaluate segmentation behavior on real conversational speech.

CONCLUSION

This project demonstrated that even a relatively small rule-based system can successfully capture several productive Hungarian morphological patterns. At the same time, the evaluation highlighted the substantial difficulties posed by Hungarian’s rich morphology, particularly in conversational language containing stacked derivational and inflectional structures.

Although simplified, the prototype provides a transparent and interpretable exploration of Hungarian morphological segmentation and illustrates both the strengths and limitations of rule-based approaches for morphologically rich low-resource NLP contexts.